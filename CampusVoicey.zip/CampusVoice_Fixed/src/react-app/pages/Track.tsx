import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Search, Loader2, Clock, Building2, MapPin, Calendar, CheckCircle2, Circle } from "lucide-react";

const API_BASE = import.meta.env.VITE_API_URL ?? "";

type Complaint = {
  id: string;
  title: string;
  description: string;
  category: string;
  location: string;
  status: string;
  createdAt: string;
};

const statusConfig: Record<string, { label: string; color: string; description: string }> = {
  Submitted: {
    label: "Submitted",
    color: "bg-amber-100 text-amber-700",
    description: "Your complaint has been submitted and is awaiting review.",
  },
  "in-progress": {
    label: "In Progress",
    color: "bg-blue-100 text-blue-700",
    description: "Administration is actively working on your issue.",
  },
  resolved: {
    label: "Resolved",
    color: "bg-emerald-100 text-emerald-700",
    description: "Your issue has been resolved. Thank you for reporting!",
  },
};

const steps = ["Submitted", "in-progress", "resolved"] as const;

// Returns which steps should be highlighted as complete
const getStepIndex = (status: string) => steps.indexOf(status as typeof steps[number]);

function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export default function Track() {
  const [searchParams] = useSearchParams();
  const [trackingId, setTrackingId] = useState(searchParams.get("id") || "");
  const [complaint, setComplaint] = useState<Complaint | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  const handleSearch = async (idToSearch?: string) => {
    const id = idToSearch ?? trackingId;
    if (!id.trim()) return;

    setLoading(true);
    setError("");
    setComplaint(null);

    try {
      const res = await fetch(`${API_BASE}/api/complaints/${id}`);
      if (!res.ok) throw new Error();
      const data = await res.json();
      setComplaint(data);
    } catch {
      setError("No complaint found with that ID. Please check and try again.");
    } finally {
      setLoading(false);
    }
  };

  // BUG FIX: useEffect was calling handleSearch() but trackingId state wasn't
  // set yet at that point (async state update). Pass the id directly.
  useEffect(() => {
    const id = searchParams.get("id");
    if (id) {
      setTrackingId(id);
      handleSearch(id);
    }
  }, [searchParams]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch();
  };

  const handleCopy = () => {
    if (!complaint) return;
    navigator.clipboard.writeText(complaint.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <main className="max-w-3xl mx-auto px-4 py-20">

        {/* Search Card */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Track Your Complaint</h1>
          <p className="text-muted-foreground">Enter your complaint ID to check its current status</p>
        </div>

        <Card className="mb-8">
          <CardContent className="pt-6">
            <form onSubmit={handleSubmit} className="flex gap-3">
              <Input
                placeholder="Enter Complaint ID (e.g. 42)"
                value={trackingId}
                onChange={(e) => setTrackingId(e.target.value)}
              />
              <Button type="submit" disabled={loading}>
                <Search className="w-4 h-4 mr-2" />
                Track
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Loading */}
        {loading && (
          <div className="text-center py-10">
            <Loader2 className="animate-spin mx-auto mb-2 text-emerald-500" size={32} />
            <p className="text-muted-foreground">Looking up complaint...</p>
          </div>
        )}

        {/* Error */}
        {!loading && error && (
          <Card className="border-red-200">
            <CardContent className="text-center py-10">
              <p className="text-red-500 font-medium">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* Result */}
        {!loading && complaint && (() => {
          const currentStepIdx = getStepIndex(complaint.status);
          return (
            <Card className="shadow-xl border rounded-2xl">
              <CardHeader>
                <CardTitle className="flex justify-between items-start gap-2">
                  <span>{complaint.title}</span>
                  <span className={`text-xs px-3 py-1 rounded-full whitespace-nowrap ${statusConfig[complaint.status]?.color ?? "bg-gray-100 text-gray-700"}`}>
                    {statusConfig[complaint.status]?.label ?? complaint.status}
                  </span>
                </CardTitle>
              </CardHeader>

              <CardContent className="space-y-5">
                {/* Status Progress Bar - BUG FIX: "in-progress" step was never highlighted because
                    old logic only checked complaint.status === step exactly, but didn't account
                    for steps BEFORE the current one. Fixed with index comparison. */}
                <div className="flex items-center gap-0">
                  {steps.map((step, idx) => (
                    <div key={step} className="flex items-center flex-1 last:flex-none">
                      <div className="flex flex-col items-center">
                        {idx <= currentStepIdx ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                        ) : (
                          <Circle className="w-5 h-5 text-gray-300" />
                        )}
                        <p className="text-xs mt-1 text-center w-16">
                          {statusConfig[step]?.label}
                        </p>
                      </div>
                      {idx < steps.length - 1 && (
                        <div className={`h-0.5 flex-1 mx-1 mb-4 ${idx < currentStepIdx ? "bg-emerald-500" : "bg-gray-200"}`} />
                      )}
                    </div>
                  ))}
                </div>

                <p className="text-gray-700 dark:text-gray-300">{complaint.description}</p>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex gap-2 items-center text-muted-foreground">
                    <Building2 size={16} />
                    <span>{complaint.category}</span>
                  </div>
                  <div className="flex gap-2 items-center text-muted-foreground">
                    <MapPin size={16} />
                    <span>{complaint.location}</span>
                  </div>
                  <div className="flex gap-2 items-center text-muted-foreground">
                    <Calendar size={16} />
                    <span>{formatDate(complaint.createdAt)}</span>
                  </div>
                  <div className="flex gap-2 items-center text-muted-foreground">
                    <Clock size={16} />
                    <span>ID: {complaint.id}</span>
                    <button
                      className="text-xs px-2 py-1 bg-gray-200 dark:bg-gray-700 rounded hover:bg-gray-300 transition-colors"
                      onClick={handleCopy}
                    >
                      {copied ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>

                <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg text-sm text-gray-600 dark:text-gray-400">
                  {statusConfig[complaint.status]?.description}
                </div>
              </CardContent>
            </Card>
          );
        })()}

        {!loading && !complaint && !error && (
          <p className="text-center text-muted-foreground">
            Enter your complaint ID above to track its status
          </p>
        )}
      </main>
    </div>
  );
}
