import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";

// BUG FIX: Admin.tsx imported Header but App.tsx already renders it globally — removed duplicate
// BUG FIX: GET complaints used hardcoded CodeSandbox URL; PATCH used relative path with no base
// Fix: use a consistent API base from env variable with fallback

const API_BASE = import.meta.env.VITE_API_URL ?? "";

type Complaint = {
  id: string;
  title: string;
  description: string;
  category: string;
  location: string;
  status: string;
  createdAt: string;
};

// BUG FIX: status filter was case-sensitive inconsistency: DB stores "Submitted"
// but filter checked "in-progress" and "resolved" (lowercase). Standardised here.
const STATUS_LABELS: Record<string, string> = {
  Submitted: "Submitted",
  "in-progress": "In Progress",
  resolved: "Resolved",
};

const STATUS_COLORS: Record<string, string> = {
  Submitted: "bg-amber-100 text-amber-700",
  "in-progress": "bg-blue-100 text-blue-700",
  resolved: "bg-emerald-100 text-emerald-700",
};

const CHART_COLORS = ["#facc15", "#3b82f6", "#10b981"];

export default function AdminPage() {
  const navigate = useNavigate();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("all");

  useEffect(() => {
    const isAdmin = localStorage.getItem("admin");
    if (!isAdmin) navigate("/admin-login");
  }, [navigate]);

  const loadComplaints = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/complaints`);
      const data = await res.json();
      setComplaints(data);
    } catch (err) {
      console.error("Error loading complaints");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadComplaints();
  }, []);

  const updateStatus = async (id: string, status: string) => {
    try {
      // BUG FIX: was using relative /api/admin/complaints/:id — needs API base
      await fetch(`${API_BASE}/api/admin/complaints/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      loadComplaints();
    } catch {
      alert("Failed to update status");
    }
  };

  const total = complaints.length;
  const submitted = complaints.filter((c) => c.status === "Submitted").length;
  const inProgress = complaints.filter((c) => c.status === "in-progress").length;
  const resolved = complaints.filter((c) => c.status === "resolved").length;

  const chartData = [
    { name: "Submitted", value: submitted },
    { name: "In Progress", value: inProgress },
    { name: "Resolved", value: resolved },
  ];

  const filtered = filter === "all" ? complaints : complaints.filter(c => c.status === filter);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <main className="max-w-6xl mx-auto px-6 py-10">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground text-sm mt-1">Manage and resolve campus complaints</p>
          </div>
          <Button
            variant="destructive"
            onClick={() => {
              localStorage.removeItem("admin");
              navigate("/admin-login");
            }}
          >
            Logout
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Total", value: total, color: "text-gray-800" },
            { label: "Submitted", value: submitted, color: "text-amber-600" },
            { label: "In Progress", value: inProgress, color: "text-blue-600" },
            { label: "Resolved", value: resolved, color: "text-emerald-600" },
          ].map((stat) => (
            <Card key={stat.label}>
              <CardContent className="p-4 text-center">
                <p className="text-sm text-gray-500">{stat.label}</p>
                <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Chart */}
        {total > 0 && (
          <Card className="mb-8">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold mb-4">Status Distribution</h2>
              <div style={{ width: "100%", height: 280 }}>
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={chartData} dataKey="value" nameKey="name" outerRadius={100} label>
                      {chartData.map((_, index) => (
                        <Cell key={index} fill={CHART_COLORS[index]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Filter Tabs */}
        <div className="flex gap-2 mb-6">
          {["all", "Submitted", "in-progress", "resolved"].map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                filter === s
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
            >
              {s === "all" ? "All" : STATUS_LABELS[s]}
            </button>
          ))}
        </div>

        {/* Complaints List */}
        {loading && <p className="text-muted-foreground">Loading complaints...</p>}
        {!loading && filtered.length === 0 && (
          <p className="text-muted-foreground">No complaints found.</p>
        )}

        {!loading && filtered.map((c) => (
          <Card key={c.id} className="mb-4">
            <CardHeader className="pb-2">
              <CardTitle className="flex justify-between items-start gap-2 text-base">
                <span>{c.title}</span>
                <span className={`text-xs px-3 py-1 rounded-full whitespace-nowrap ${STATUS_COLORS[c.status] ?? "bg-gray-100 text-gray-600"}`}>
                  {STATUS_LABELS[c.status] ?? c.status}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-3 text-sm text-gray-700 dark:text-gray-300">{c.description}</p>
              <div className="flex gap-4 text-xs text-muted-foreground mb-4">
                <span><b>Category:</b> {c.category}</span>
                <span><b>Location:</b> {c.location}</span>
                <span><b>ID:</b> {c.id}</span>
              </div>
              <div className="flex gap-2 flex-wrap">
                <Button
                  size="sm"
                  variant="secondary"
                  disabled={c.status === "Submitted"}
                  onClick={() => updateStatus(c.id, "Submitted")}
                >
                  Pending
                </Button>
                <Button
                  size="sm"
                  disabled={c.status === "in-progress"}
                  onClick={() => updateStatus(c.id, "in-progress")}
                >
                  In Progress
                </Button>
                <Button
                  size="sm"
                  disabled={c.status === "resolved"}
                  className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50"
                  onClick={() => updateStatus(c.id, "resolved")}
                >
                  Resolved
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </main>
    </div>
  );
}
