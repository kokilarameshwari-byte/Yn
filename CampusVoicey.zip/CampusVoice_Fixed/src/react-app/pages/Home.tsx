import { useState } from "react";
import { Building2, Wifi, Zap, Shield, Trash2, HelpCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";

const API_BASE = import.meta.env.VITE_API_URL ?? "";

export default function Home() {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("Main Building");
  const [submitting, setSubmitting] = useState(false);

  const submitIssue = async (e: React.FormEvent) => {
    e.preventDefault();

    // BUG FIX: Also validate category is selected
    if (!title || !description || !category) {
      alert("Please fill all fields and select a category");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/api/complaints`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description, category, location }),
      });

      const data = await res.json();

      if (!data.id) {
        alert("Complaint ID not generated");
        return;
      }

      navigate(`/track?id=${data.id}`);

      setTitle("");
      setDescription("");
      setCategory("");
    } catch (err) {
      alert("Submission failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const categories = [
    { name: "Infrastructure", desc: "Buildings, roads", icon: Building2 },
    { name: "Technology", desc: "Internet, computers", icon: Wifi },
    { name: "Utilities", desc: "Electricity, water", icon: Zap },
    { name: "Safety", desc: "Security issues", icon: Shield },
    { name: "Sanitation", desc: "Waste management", icon: Trash2 },
    { name: "Other", desc: "General complaints", icon: HelpCircle },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero */}
      <div className="text-center mt-10 px-6">
        <h2 className="text-4xl font-bold text-gray-800 dark:text-gray-100">
          Report Campus Issues
          <span className="text-emerald-500"> Anonymously</span>
        </h2>
        <p className="text-gray-500 mt-4 max-w-xl mx-auto">
          Help improve our campus by reporting issues. Track your complaint with a unique ID.
        </p>
      </div>

      {/* Form */}
      <div className="max-w-xl mx-auto mt-10 bg-white dark:bg-gray-900 rounded-xl shadow p-6 mb-10">
        <h3 className="text-xl font-semibold mb-2">Submit a New Issue</h3>
        <p className="text-gray-500 mb-6">Describe the problem you've encountered.</p>

        {/* Category selector */}
        <p className="text-sm font-medium mb-3 text-gray-700 dark:text-gray-300">
          Select Category <span className="text-red-500">*</span>
        </p>
        <div className="grid grid-cols-2 gap-4 mb-6">
          {categories.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.name}
                type="button"
                onClick={() => setCategory(cat.name)}
                className={
                  "border rounded-lg p-4 text-left flex gap-3 items-start transition-colors " +
                  (category === cat.name
                    ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/30"
                    : "border-gray-200 dark:border-gray-700 hover:border-emerald-300")
                }
              >
                <Icon size={22} className={category === cat.name ? "text-emerald-600" : "text-gray-500"} />
                <div>
                  <div className="font-semibold text-sm">{cat.name}</div>
                  <div className="text-xs text-gray-500">{cat.desc}</div>
                </div>
              </button>
            );
          })}
        </div>

        <form onSubmit={submitIssue} className="space-y-4">
          <select
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="w-full border rounded-lg p-3 dark:bg-gray-800 dark:border-gray-700"
          >
            <option>Main Building</option>
            <option>Library</option>
            <option>Science Block</option>
            <option>Cafeteria</option>
            <option>Sports Complex</option>
            <option>Dormitory</option>
            <option>Parking Area</option>
            <option>Outdoor/Campus Grounds</option>
            <option>Other</option>
          </select>

          <input
            placeholder="Brief summary of the issue"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full border rounded-lg p-3 dark:bg-gray-800 dark:border-gray-700"
          />

          <textarea
            placeholder="Provide as much detail as possible about the issue..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            className="w-full border rounded-lg p-3 dark:bg-gray-800 dark:border-gray-700"
          />

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:opacity-60 disabled:cursor-not-allowed text-white py-3 rounded-lg font-semibold transition-colors"
          >
            {submitting ? "Submitting..." : "Submit Issue Report"}
          </button>
        </form>

        {/* BUG FIX: Track button was floating outside JSX return — moved inside */}
        <div className="mt-4 flex justify-center">
          <button
            onClick={() => navigate("/track")}
            className="px-6 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg font-medium transition"
          >
            🔍 Track Complaint
          </button>
        </div>
      </div>
    </div>
  );
}
