import express from "express";
import cors from "cors";
import db from "./database.js";
import complaintsRoute from "./routes/complaints.js";

const app = express();

app.use(cors({ origin: "*" }));
app.use(express.json());

// BUG FIX: server.js was registering both a router at /api AND duplicate
// inline handlers also at /api/complaints — GET all and GET by id were defined
// twice. Removed the duplicate inline routes; the router handles POST.
// The inline GET routes were kept since the router only had POST.
app.use("/api", complaintsRoute);

// get all complaints
app.get("/api/complaints", (req, res) => {
  try {
    const rows = db.prepare("SELECT * FROM complaints ORDER BY createdAt DESC").all();
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// get complaint by id
app.get("/api/complaints/:id", (req, res) => {
  try {
    const { id } = req.params;
    const row = db.prepare("SELECT * FROM complaints WHERE id = ?").get(id);
    if (!row) return res.status(404).json({ error: "Complaint not found" });
    res.json(row);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin update status
// BUG FIX: No validation on status value — added whitelist check
const VALID_STATUSES = ["Submitted", "in-progress", "resolved"];

app.patch("/api/admin/complaints/:id", (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!VALID_STATUSES.includes(status)) {
      return res.status(400).json({ error: "Invalid status value" });
    }

    const result = db
      .prepare("UPDATE complaints SET status = ? WHERE id = ?")
      .run(status, id);

    if (result.changes === 0) {
      return res.status(404).json({ error: "Complaint not found" });
    }

    res.json({ message: "Status updated" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/logout", (_, res) => {
  res.json({ message: "Logged out" });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log("Server running on port", PORT);
});
